package com.lastsave;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LastsaveBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LastsaveBackendApplication.class, args);
	}

}
